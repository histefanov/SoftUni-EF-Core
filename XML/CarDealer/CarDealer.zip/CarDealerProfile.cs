﻿using AutoMapper;
using CarDealer.DTO.Import;
using CarDealer.Models;

namespace CarDealer
{
    public class CarDealerProfile : Profile
    {
        public CarDealerProfile()
        {
            this.CreateMap<PartImportDto, Part>();
            this.CreateMap<CustomerImportDto, Customer>();
            this.CreateMap<SaleImportDto, Sale>();
        }
    }
}
